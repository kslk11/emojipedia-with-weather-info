# Weather-app
Basic weather app

check it out here: https://weather-feather.netlify.app/
